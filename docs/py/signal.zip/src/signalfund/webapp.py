"""Signal web UI — an interactive, zero-dependency local dashboard.

Backend on Python's stdlib ``http.server`` (no Flask / FastAPI / new pip deps).
It serves a vanilla-JS single-page app and a small JSON API that drives the real
pipeline: run sourcing, browse the ranked digest, generate memos, edit the
thesis, and run the Phase 0 backtest — all from the browser.

    PYTHONPATH=src python -m signalfund.webapp              # http://127.0.0.1:8000
    PYTHONPATH=src python -m signalfund.webapp --port 8765
    PYTHONPATH=src python -m signalfund.webapp --no-open    # don't auto-open a browser

Offline-first: with no API keys it runs the demo path (bundled fixtures, heuristic
scorer), exactly like the CLI. Binds to localhost only.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import os
import pathlib
import threading
import uuid
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import yaml

from . import backtest as backtest_mod
from . import llm
from . import memo as memo_mod
from . import orchestrator
from .models import Candidate

ROOT = pathlib.Path(__file__).resolve().parents[2]
WEB = pathlib.Path(__file__).resolve().parent / "web"
THESIS_PATH = ROOT / "config" / "thesis.yaml"
# Append-only human-feedback log (👍/👎 on surfaced candidates). Rows are
# eval-compatible (name/summary/tags/label) so they can later seed eval_set.jsonl.
FEEDBACK_PATH = ROOT / "data" / "feedback.jsonl"

# Agent-memo jobs (S-03): the diligence agent can take a while — each step is bounded, but the
# whole run isn't instant — so it runs in a background thread and the UI polls its live
# progress instead of blocking the HTTP request. Single-process/localhost only; a lock is enough.
_JOBS_LOCK = threading.Lock()
_JOBS: dict = {}  # job_id -> {"status": "running"|"done"|"error", "trail": [...], "result"|"error": ...}

_STATIC_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".svg": "image/svg+xml",
}


def _out_dir() -> pathlib.Path:
    return pathlib.Path(os.getenv("SIGNAL_OUT_DIR", "out"))


def _read_out_json(name: str):
    p = _out_dir() / name
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return None
    return None


def _list_memos() -> list:
    mdir = _out_dir() / "memos"
    if not mdir.exists():
        return []
    return [p.name for p in sorted(mdir.glob("*.md"))]


# Composite signals the user can toggle in the UI. `tier`: free = no paid key needed;
# premium = needs a paid API key (the user may still enable it — it just contributes 0
# without the key, graceful absence). `env` is the API key checked for key_present.
SIGNALS = [
    {"name": "code_health",   "tier": "free",    "env": "GITHUB_TOKEN"},
    {"name": "onchain",       "tier": "free",    "env": None,
     "label": "onchain · DefiLlama", "group": "onchain"},
    {"name": "nansen",        "tier": "premium", "env": "NANSEN_API_KEY",
     "label": "onchain · Nansen (smart-money)", "group": "onchain"},
    {"name": "social",        "tier": "free",    "env": "NEYNAR_API_KEY"},
    # Sourcing source (not an enrich pass): watches curated smart accounts' Farcaster
    # follow lists and surfaces new convergence as candidates. Toggle gates the source
    # in orchestrator.run; keyless = skips itself (graceful absence).
    {"name": "network_radar", "tier": "free",    "env": "NEYNAR_API_KEY",
     "label": "network radar · Farcaster follows"},
    {"name": "pre_public",    "tier": "free",    "env": "EVERTRACE_API_KEY"},
    # `team` is dual-tier — the two paths toggle independently:
    {"name": "team_github",   "tier": "free",    "env": "GITHUB_TOKEN",
     "label": "team · GitHub", "group": "team"},
    {"name": "team_harmonic", "tier": "premium", "env": "HARMONIC_API_KEY",
     "label": "team · Harmonic", "group": "team"},
    {"name": "messari",       "tier": "premium", "env": "MESSARI_API_KEY",
     "label": "funding / stage-gate · Messari"},
]


def _signals_state() -> list:
    """Per-signal tier, display label, and whether its key is present (free signals with
    no key -> True)."""
    return [{"name": s["name"], "tier": s["tier"], "env": s["env"],
             "label": s.get("label", s["name"]), "group": s.get("group"),
             "key_present": (s["env"] is None) or bool(os.getenv(s["env"]))}
            for s in SIGNALS]


# Scorer-model dropdown options for the UI. "auto" + "heuristic" are always available;
# the rest mirror llm.PROVIDERS and report whether their key/endpoint is present.
_PROVIDER_UI = [
    ("auto", "Auto (best available)", None),
    ("anthropic", "Claude", "ANTHROPIC_API_KEY"),
    ("groq", "Groq (free)", "GROQ_API_KEY"),
    ("gemini", "Gemini (free)", "GEMINI_API_KEY"),
    ("openrouter", "OpenRouter (free)", "OPENROUTER_API_KEY"),
    ("ollama", "Local (Ollama)", "OLLAMA_BASE_URL"),
    ("heuristic", "Heuristic (no LLM)", None),
]


def _providers_state() -> list:
    out = []
    for name, label, env in _PROVIDER_UI:
        always = name in ("auto", "heuristic")
        out.append({"name": name, "label": label, "env": env,
                    "available": True if always else llm._provider_available(name),
                    "model": None if always else llm.provider_model(name)})
    return out


def _scorer_label() -> str:
    """Human label for the scorer that WOULD run now (honours SIGNAL_LLM_PROVIDER)."""
    p = llm.current_provider()
    return "HeuristicScorer" if p == "heuristic" else f"LLMScorer ({p})"


def _apply_scorer_provider(body: dict) -> None:
    """Set SIGNAL_LLM_PROVIDER from a request's `scorer_provider` for this run.
    'auto' clears it (auto-order); a provider name pins it; unknown is ignored."""
    prov = body.get("scorer_provider")
    if not isinstance(prov, str) or not prov:
        return
    if prov == "auto":
        os.environ.pop("SIGNAL_LLM_PROVIDER", None)
    else:
        os.environ["SIGNAL_LLM_PROVIDER"] = prov


def _feedback_votes() -> dict:
    """Collapse the append-only feedback log to the latest vote per candidate.

    Returns {name: "up"|"down"} — entries whose latest row is a "clear" are dropped.
    """
    if not FEEDBACK_PATH.exists():
        return {}
    latest = {}
    for line in FEEDBACK_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        latest[row.get("name")] = row.get("label")
    return {name: lbl for name, lbl in latest.items() if lbl in ("up", "down")}


def build_state() -> dict:
    """The /api/state payload — the full snapshot the web UI boots from. Module-level so the
    static-demo builder (scripts/build_static_demo.py) can bake it without running a server."""
    thesis_text = THESIS_PATH.read_text(encoding="utf-8")
    try:
        parsed = yaml.safe_load(thesis_text)
    except yaml.YAMLError:
        parsed = None
    return {
        "digest": _read_out_json("digest.json"),
        "backtest": _read_out_json("backtest_report.json"),
        "sourceHealth": _read_out_json("source_health.json") or [],
        "memos": _list_memos(),
        "thesis": thesis_text,
        "thesisParsed": parsed,
        "outDir": str(_out_dir()),
        "scorer": _scorer_label(),
        "providers": _providers_state(),
        "current": llm.current_provider(),
        "signals": _signals_state(),
        "feedback": _feedback_votes(),
    }


def _write_memo_file(c: Candidate, md: str) -> str:
    out = _out_dir() / "memos"
    out.mkdir(parents=True, exist_ok=True)
    fname = f"{memo_mod._slug(c.name)}.md"
    (out / fname).write_text(md, encoding="utf-8")
    return fname


def _run_agent_job(job_id: str, c: Candidate, thesis: dict) -> None:
    """Background thread body for an agent memo (S-03): drives run_diligence_events(), pushing
    each step into the job's `trail` as it happens so /api/memo/progress can poll live status,
    then writes the memo file and stores the final result. Never lets an exception escape —
    a broken run surfaces as job status 'error', it doesn't hang the poller."""
    from . import agent as agent_mod
    trail = []
    try:
        for ev in agent_mod.run_diligence_events(c, thesis):
            if ev.get("event") == "done":
                result = {k: v for k, v in ev.items() if k != "event"}
                fname = _write_memo_file(c, result["memo"])
                tools = [s.get("tool") for s in result.get("trail", []) if s.get("tool") != "finish"]
                with _JOBS_LOCK:
                    _JOBS[job_id] = {
                        "status": "done", "trail": result.get("trail", trail),
                        "result": {"ok": True, "name": fname, "markdown": result["memo"],
                                  "scorer": _scorer_label(), "agent": result.get("agent", True),
                                  "tools": tools, "runStatus": result.get("status", "complete")},
                    }
            else:
                trail.append(ev)
                with _JOBS_LOCK:
                    if job_id in _JOBS:
                        _JOBS[job_id]["trail"] = list(trail)
    except Exception as e:  # noqa: BLE001 — surfaced to the poller, never left hanging
        with _JOBS_LOCK:
            _JOBS[job_id] = {"status": "error", "trail": trail, "error": f"{type(e).__name__}: {e}"}


def _start_job(target, *args) -> None:
    """Run `target` in a background thread — or inline where threads don't exist (the in-browser
    Pyodide demo raises RuntimeError on Thread.start). Inline still records the job, so the UI's
    progress poll simply finds it already finished."""
    try:
        threading.Thread(target=target, args=args, daemon=True).start()
    except RuntimeError:
        target(*args)


# ---- API handlers -----------------------------------------------------------------------
# Transport-agnostic: each returns (status, payload). The stdlib Handler below serves them over
# HTTP locally; the GitHub Pages demo calls dispatch() directly inside Pyodide, so both paths run
# exactly the same code.

def _api_run(body: dict):
    demo = bool(body.get("demo", True))
    try:
        limit = max(1, int(body.get("limit", 25)))
    except (TypeError, ValueError):
        limit = 25
    # User-selected signals. A list -> only those contribute; absent/None -> all on.
    es = body.get("enabled_signals")
    enabled = {s for s in es if isinstance(s, str)} if isinstance(es, list) else None
    _apply_scorer_provider(body)   # user-chosen LLM provider for this run
    buf = io.StringIO()
    ok, err = True, None
    try:
        with contextlib.redirect_stdout(buf):
            orchestrator.run(demo=demo, limit=limit, enabled_signals=enabled)
    except Exception as e:  # live sources may fail without keys — surface, don't crash
        ok, err = False, f"{type(e).__name__}: {e}"
    return 200, {"ok": ok, "error": err, "log": buf.getvalue(),
                 "scorer": _scorer_label(),  # the scorer that actually ran
                 "digest": _read_out_json("digest.json") or [],
                 "sourceHealth": _read_out_json("source_health.json") or []}


def _api_backtest():
    gt = str(ROOT / "data" / "backtest" / "ground_truth.sample.json")
    buf = io.StringIO()
    ok, err = True, None
    try:
        with contextlib.redirect_stdout(buf):
            backtest_mod.run(gt)
    except Exception as e:
        ok, err = False, f"{type(e).__name__}: {e}"
    return 200, {"ok": ok, "error": err, "log": buf.getvalue(),
                 "backtest": _read_out_json("backtest_report.json")}


def _api_get_memo(name: str):
    if not name or "/" in name or ".." in name:
        return 400, {"error": "bad name"}
    path = _out_dir() / "memos" / name
    if not path.is_file():
        return 404, {"error": "not found"}
    return 200, {"name": name, "markdown": path.read_text(encoding="utf-8")}


def _api_make_memo(body: dict):
    digest = _read_out_json("digest.json") or []
    try:
        idx = int(body.get("index", 0))
    except (TypeError, ValueError):
        idx = -1
    if idx < 0 or idx >= len(digest):
        return 400, {"ok": False, "error": "no such candidate"}
    cand = digest[idx].get("candidate", {})
    try:
        c = Candidate(**cand)
    except TypeError:
        c = Candidate(name=cand.get("name", "?"), source=cand.get("source", ""),
                      url=cand.get("url", ""), summary=cand.get("summary", ""),
                      signal_metric=cand.get("signal_metric", ""),
                      tags=cand.get("tags", []), raw=cand.get("raw", {}))
    thesis = yaml.safe_load(THESIS_PATH.read_text(encoding="utf-8"))
    _apply_scorer_provider(body)   # user-chosen LLM provider for this memo

    if not body.get("agent"):      # single-shot memo: fast, stays synchronous
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            md = memo_mod.build_memo(c, thesis)
        fname = _write_memo_file(c, md)
        return 200, {"ok": True, "name": fname, "markdown": md, "log": buf.getvalue(),
                     "scorer": _scorer_label(), "agent": False, "tools": []}

    # Agent memo: can take a while (bounded per-step, but not instant) — run it in the
    # background and let the UI poll /api/memo/progress for live step-by-step status
    # instead of blocking this request (S-03: "streams step-by-step progress to the UI").
    job_id = uuid.uuid4().hex[:12]
    with _JOBS_LOCK:
        _JOBS[job_id] = {"status": "running", "trail": []}
    _start_job(_run_agent_job, job_id, c, thesis)
    return 200, {"ok": True, "streaming": True, "job_id": job_id}


def _api_memo_progress(job_id: str):
    with _JOBS_LOCK:
        job = _JOBS.get(job_id)
        if job is None:
            return 404, {"error": "no such job"}
        return 200, dict(job)  # shallow copy — safe to serialize outside the lock


def _api_feedback(body: dict):
    """Record a 👍/👎 (or 'clear') on a digest candidate, by digest index.

    Appends an eval-compatible row to data/feedback.jsonl. 'up' = on-thesis
    (eval label True), 'down' = off-thesis (False), 'clear' = retract.
    """
    label = body.get("label")
    if label not in ("up", "down", "clear"):
        return 400, {"ok": False, "error": "label must be up/down/clear"}
    digest = _read_out_json("digest.json") or []
    try:
        idx = int(body.get("index", -1))
    except (TypeError, ValueError):
        idx = -1
    if idx < 0 or idx >= len(digest):
        return 400, {"ok": False, "error": "no such candidate"}
    entry = digest[idx]
    cand = entry.get("candidate", {})
    eval_label = {"up": True, "down": False, "clear": None}[label]
    row = {
        "name": cand.get("name"),
        "source": cand.get("source"),
        "summary": cand.get("summary", ""),
        "tags": cand.get("tags", []),
        "label": label,            # up | down | clear (audit value)
        "eval_label": eval_label,  # True | False | None — for seeding eval_set.jsonl
        "score": entry.get("score"),
        "ts": datetime.now(timezone.utc).isoformat(),
    }
    FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with FEEDBACK_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row) + "\n")
    return 200, {"ok": True, "name": row["name"], "votes": _feedback_votes()}


def _api_save_thesis(body: dict):
    # Two ways to save: a structured object from the sectioned editor (preferred —
    # keeps unknown keys like `updated`), or raw YAML text from the Advanced fallback.
    if isinstance(body.get("thesis"), dict):
        try:
            text = yaml.safe_dump(body["thesis"], sort_keys=False, allow_unicode=True)
            parsed = yaml.safe_load(text)          # re-parse to validate the round-trip
            if not isinstance(parsed, dict):
                raise ValueError("thesis must be a mapping")
        except (yaml.YAMLError, ValueError) as e:
            return 400, {"ok": False, "error": f"Invalid thesis: {e}"}
    else:
        text = body.get("text", "")
        try:
            parsed = yaml.safe_load(text)
            if not isinstance(parsed, dict):
                raise ValueError("thesis must be a YAML mapping")
        except (yaml.YAMLError, ValueError) as e:
            return 400, {"ok": False, "error": f"Invalid YAML: {e}"}
    THESIS_PATH.write_text(text, encoding="utf-8")
    return 200, {"ok": True, "thesisParsed": parsed, "text": text}


def dispatch(method: str, url: str, body: dict = None):
    """Route one API request -> (status, payload). `url` is the path plus optional query string."""
    route = urlparse(url)
    path, query = route.path, parse_qs(route.query)
    method, body = method.upper(), body or {}
    if method in ("GET", "HEAD"):
        if path == "/api/state":
            return 200, build_state()
        if path == "/api/digest":
            return 200, _read_out_json("digest.json") or []
        if path == "/api/backtest":
            return 200, _read_out_json("backtest_report.json")
        if path == "/api/memos":
            return 200, {"memos": _list_memos()}
        if path == "/api/feedback":
            return 200, {"votes": _feedback_votes()}
        if path == "/api/memo":
            return _api_get_memo(query.get("name", [""])[0])
        if path == "/api/memo/progress":
            return _api_memo_progress(query.get("job_id", [""])[0])
        if path == "/api/thesis":
            return 200, {"text": THESIS_PATH.read_text(encoding="utf-8")}
    elif method == "POST":
        if path == "/api/run":
            return _api_run(body)
        if path == "/api/backtest":
            return _api_backtest()
        if path == "/api/memo":
            return _api_make_memo(body)
        if path == "/api/feedback":
            return _api_feedback(body)
    elif method == "PUT":
        if path == "/api/thesis":
            return _api_save_thesis(body)
    return 404, {"error": "not found"}


def dispatch_json(method: str, url: str, body_json: str = "") -> str:
    """dispatch() over JSON strings — the bridge the in-browser (Pyodide) demo calls from JS.
    Returns {"status": int, "data": payload} serialized; default=str matches the HTTP path."""
    try:
        body = json.loads(body_json) if body_json else {}
    except json.JSONDecodeError:
        body = {}
    status, data = dispatch(method, url, body if isinstance(body, dict) else {})
    return json.dumps({"status": status, "data": data}, default=str)


class Handler(BaseHTTPRequestHandler):
    server_version = "SignalWeb"

    # ---- low-level responders ---------------------------------------------
    def _send(self, body: bytes, ctype: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, status: int = 200) -> None:
        # default=str so YAML-parsed dates (e.g. thesis `updated:`) serialize cleanly
        self._send(json.dumps(obj, default=str).encode("utf-8"), "application/json", status)

    def _static(self, filename: str) -> None:
        path = (WEB / filename).resolve()
        if not str(path).startswith(str(WEB)) or not path.is_file():
            return self._json({"error": "not found"}, 404)
        ctype = _STATIC_TYPES.get(path.suffix, "application/octet-stream")
        self._send(path.read_bytes(), ctype)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw or b"{}")
        except json.JSONDecodeError:
            return {}

    def log_message(self, fmt, *args):  # quieter console
        pass

    # ---- routing ----------------------------------------------------------
    def _api(self, method: str) -> None:
        body = {} if method == "GET" else self._body()
        status, data = dispatch(method, self.path, body if isinstance(body, dict) else {})
        self._json(data, status)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/" or path == "/index.html":
            return self._static("index.html")
        if path in ("/app.js", "/styles.css"):
            return self._static(path.lstrip("/"))
        return self._api("GET")

    def do_POST(self):
        return self._api("POST")

    def do_PUT(self):
        return self._api("PUT")


def serve(host: str = "127.0.0.1", port: int = 8000, open_browser: bool = True) -> None:
    httpd = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}"
    print(f"[signal-web] serving Signal UI at {url}  (Ctrl+C to stop)")
    print(f"[signal-web] output dir: {_out_dir()}  ·  thesis: {THESIS_PATH}")
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[signal-web] stopped.")
    finally:
        httpd.server_close()


def main():
    # Defaults are env-configurable so the SAME code runs localhost-only locally and binds
    # 0.0.0.0 on a PaaS — without changing local behavior. Flags still override env.
    #   PORT             injected by most PaaS (Render/Heroku/Fly). Its mere presence flips the
    #                    host default to 0.0.0.0 so the platform can detect the open port; locally
    #                    (no PORT) we stay on 127.0.0.1. Falls back to SIGNAL_WEB_PORT, then 8000.
    #   SIGNAL_WEB_HOST  explicit override of the host default (e.g. force 0.0.0.0 or lock to localhost).
    default_host = os.getenv("SIGNAL_WEB_HOST") or ("0.0.0.0" if os.getenv("PORT") else "127.0.0.1")
    default_port = int(os.getenv("PORT", os.getenv("SIGNAL_WEB_PORT", "8000")))
    p = argparse.ArgumentParser(description="Signal — interactive web UI (stdlib, zero deps)")
    p.add_argument("--host", default=default_host,
                   help="bind host (default: localhost only; env SIGNAL_WEB_HOST)")
    p.add_argument("--port", type=int, default=default_port,
                   help="bind port (default: env PORT / SIGNAL_WEB_PORT / 8000)")
    p.add_argument("--no-open", action="store_true", help="don't auto-open a browser")
    args = p.parse_args()
    serve(host=args.host, port=args.port, open_browser=not args.no_open)


if __name__ == "__main__":
    main()
